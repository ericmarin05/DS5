//parte2

// suma 
var a=8, b=6;
var suma = a + b;
console.log(suma);

//resta
resta = a - b;
console.log(resta);

//multiplicacion
multi = a*b;
console.log(multi);

//division
division = a/b;
console.log(division);

//parte 3
let palabra1 = "Eric";
let palabra2 = "Marin";

const resultado = palabra1 + " " + palabra2;

console.log(resultado);
//parte4
let miObjeto = {
    numero: 42,            // Number
    texto: "Eric Marin",  // String
    booleano: true,        // Boolean
    objetoVacio: {}        // Objeto vacío
};

console.log(miObjeto);

function sumaMultiplos(numero) {
    let suma = 0;
    for (let i = 1; i < numero; i++) {
        if (i % 3 === 0 || i % 5 === 0) {
            suma += i;
        }
    }
    return suma;
}

// Ejemplo de uso:
let resultado2 = sumaMultiplos(10);
console.log(resultado2); // Debería imprimir 23

